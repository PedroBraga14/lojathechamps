import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Notification() {
  return (
    <View style={design.notify}>
      <Text> notify </Text>
    </View>
  );
}

const design = StyleSheet.create({


})
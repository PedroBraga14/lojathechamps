import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Header from '../components/Header';
import Banner from '../components/Banner';
import Menu from '../components/Menu';
import Notification from './Notification';
import {createStackNavigator} from '@react-navigation/stack';
import {NatvigationContainer} from '@react-navigation/native';

const Stack = createStackNavigator();

export default function Home() {
  return (
  <NatvigationContainer independent={true}>
    <Stack.Navigator>
      <Stack.Screen name = 'Start' component={Start} />
      <Stack.Screen name= 'Notification' component={Notification} />
    </Stack.Navigator>
  </NatvigationContainer>
  );
}
function Start({navigation}) {
  return (
  <View style={design.container}>
    <Header />
    <Banner />
    <Menu screen = {navigation}/>
  </View>
 );
}
const design = StyleSheet.create({
  container: {
    display: 'flex',
    flex: 1,
  },
});
import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

import {
  useFonts,
  Merriweather_400Regular_Italic,
} from '@expo-google-fonts/merriweather';
import {NavigationContainer} from '@react-navigation/native';

import 'react-native-gesture-handler';
import {createStackNavigator} from '@react-navigation/stack';
//import Notification from './screens/Notification';
import Home from './screens/Home';


const Stack = createStackNavigator();

export default function App() {

  var [ChargedFont] = useFonts ({


    Merriweather_400Regular_Italic


  });

  if (!ChargedFont) {
    return null;
  }


  return (
    <NavigationContainer>
  
    <Stack.Navigator>
    
      <Stack.Screen name = 'Home' component = {Home} />
      //<Stack.Screen name = 'Notification' component = {Notification} />

    </Stack.Navigator>

    </NavigationContainer>
  );
}


import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { TouchableOpacity} from "react-native";
import { Ionicons } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import { SimpleLineIcons } from '@expo/vector-icons';


export default function Menu(props) {

  return (
    <View style={design.menu}>

      <TouchableOpacity onPress={alert}>
      <SimpleLineIcons name="home" size={21} color="black" style = {design.homeIcon}/>
          <Text style = {design.menuText}>Home </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => props.screen.navigate('Notification')}>
      <AntDesign name="notification" size={21} color="black" style = {design.notifyIcon}/>
          <Text style = {design.menuText}>Notification </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={alert}>
      <Ionicons name="md-menu-outline" size={22} color="black" style = {design.moreIcon}/>
          <Text style = {design.menuText}>More </Text>
      </TouchableOpacity>

    </View>
  );
}

const design = StyleSheet.create({

menu: {
  backgroundColor: '#F4A460',
  flex: 0.09,

  justifyContent: 'center',
  flexDirection: 'row',
},

menuText: {
  marginTop: 'auto',
  marginBottom: 'auto',
  padding: 5,

},

homeIcon: {


},

notifyIcon: {


},

moreIcon: {


},

})


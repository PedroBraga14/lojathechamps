import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { SimpleLineIcons } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import { EvilIcons } from '@expo/vector-icons';
import { TouchableOpacity} from "react-native";

export default function Header() {
  return (
    <View style={design.header}>
      <View style={design.logo}>
        <Text style = {design.name}>|The-Champs™</Text>
      </View>

     {/* <View style={design.search}>
        <AntDesign
          name="search1"
          size={18}
          color="black"
          style={design.iconSearch}
        />
      </View> */}

      <TouchableOpacity onPress={alert}>
      <View style={design.favorite}>
        <EvilIcons name="heart" size={24} color="black" />
      </View>
      </TouchableOpacity>

      <TouchableOpacity onPress={alert}>
      <View style={design.bag}>
        <SimpleLineIcons name="handbag" size={16} color="black" />
      </View>
    </TouchableOpacity>      
    </View>
  );
}

const design = StyleSheet.create({
  header: {
    backgroundColor: '#C0C0C0',
    flexDirection: 'row',
    flex: 0.1,

  },

  name: {
    fontFamily: "Merriweather_400Regular_Italic",
    fontSize: 18,
  },

  logo: {
    paddingTop: 45,
    marginRight: "auto",
    marginLeft: 135,
  },

  /*iconSearch: {},

  /*search: {
    flex: 0.56,
    paddingTop: 45,
    paddingLeft: 22,
    flexDirection: 'row',
  }, */

  favorite: {
    paddingRight: 2,
    paddingTop: 45, 
  },

  bag: {
    paddingRight: 10,
    paddingTop: 45,
  },
});

import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Banner() {
  return (
    <View style={design.banner}>
      <Image source={require("../assets/banner.jpeg")} style = {design.bannerImage}/>
    </View>
  );
}

const design = StyleSheet.create({
  banner: {
    backgroundColor: '#FFDEAD',
    textAlign: 'left',
    flex: 0.20,
  },

  bannerImage: {
    width: "100%",
    height:"100%",
  },
})